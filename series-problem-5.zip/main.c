/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//series-0,0,7,6,14,12,...........//
#include <stdio.h>
#include<math.h>
int main()
{
    int n;
    int x=1;
    printf("Enter the value of n:");
    scanf("%d",&n);
   
       if(n%2!=0)
       {
           int x=7*(n/2);
           
       }
       else
       {
           int x=6*(n/2-1);
         
       }
       printf("The value of the term is:%d\n",x);
   
}